<?php

/**
 * StudyPilot AI - API Configuration Test
 * Run this file to check if your Gemini API key is configured correctly
 */

require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/ai_handler.php';

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>API Configuration Test - StudyPilot AI</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background: #f3f4f6;
        }

        .card {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }

        h1 {
            color: #1f2937;
        }

        .status {
            padding: 15px;
            border-radius: 8px;
            margin: 15px 0;
        }

        .success {
            background: #d1fae5;
            color: #065f46;
            border-left: 4px solid #10b981;
        }

        .error {
            background: #fee2e2;
            color: #991b1b;
            border-left: 4px solid #ef4444;
        }

        .warning {
            background: #fef3c7;
            color: #92400e;
            border-left: 4px solid #f59e0b;
        }

        code {
            background: #f3f4f6;
            padding: 2px 6px;
            border-radius: 4px;
            font-family: 'Courier New', monospace;
        }

        .info {
            background: #e0e7ff;
            padding: 15px;
            border-radius: 8px;
            margin: 15px 0;
        }
    </style>
</head>

<body>
    <div class="card">
        <h1>📚 StudyPilot AI - Configuration Test</h1>

        <?php
        // Check if API key is configured
        $apiKeyConfigured = defined('GEMINI_API_KEY') && GEMINI_API_KEY !== 'YOUR_GEMINI_API_KEY_HERE';

        if (!$apiKeyConfigured) {
            echo '<div class="status error">';
            echo '<h3>❌ API Key Not Configured</h3>';
            echo '<p>Your Gemini API key has not been set up yet.</p>';
            echo '<p><strong>Current value:</strong> <code>' . GEMINI_API_KEY . '</code></p>';
            echo '</div>';

            echo '<div class="info">';
            echo '<h4>How to Fix:</h4>';
            echo '<ol>';
            echo '<li>Get your Gemini API key from: <a href="https://makersuite.google.com/app/apikey" target="_blank">https://makersuite.google.com/app/apikey</a></li>';
            echo '<li>Open <code>includes/config.php</code></li>';
            echo '<li>Find the line: <code>define(\'GEMINI_API_KEY\', \'YOUR_GEMINI_API_KEY_HERE\');</code></li>';
            echo '<li>Replace <code>YOUR_GEMINI_API_KEY_HERE</code> with your actual API key</li>';
            echo '<li>Save the file and refresh this page</li>';
            echo '</ol>';
            echo '</div>';
        } else {
            echo '<div class="status success">';
            echo '<h3>✅ API Key Configured</h3>';
            echo '<p>Your Gemini API key is set (length: ' . strlen(GEMINI_API_KEY) . ' characters)</p>';
            echo '</div>';

            // Test API connection
            echo '<div class="status warning">';
            echo '<h3>🔄 Testing API Connection...</h3>';
            echo '<p>Attempting to connect to Google Gemini API...</p>';
            echo '</div>';

            $apiWorks = testGeminiAPI();

            if ($apiWorks) {
                echo '<div class="status success">';
                echo '<h3>✅ API Connection Successful!</h3>';
                echo '<p>Your Gemini API is working correctly. You can now generate study plans!</p>';
                echo '<p><a href="dashboard.php" style="color: #6366f1; font-weight: bold;">Go to Dashboard →</a></p>';
                echo '</div>';
            } else {
                echo '<div class="status error">';
                echo '<h3>❌ API Connection Failed</h3>';
                echo '<p>The API key is configured but the connection test failed.</p>';
                echo '<h4>Possible Issues:</h4>';
                echo '<ul>';
                echo '<li>Invalid API key</li>';
                echo '<li>API key doesn\'t have Gemini API enabled</li>';
                echo '<li>Network/firewall blocking the connection</li>';
                echo '<li>API quota exceeded</li>';
                echo '</ul>';
                echo '<p>Check your XAMPP error logs at: <code>C:\\xampp\\apache\\logs\\error.log</code></p>';
                echo '</div>';
            }
        }
        ?>

        <div class="info">
            <h4>Other Configuration Checks:</h4>
            <ul>
                <li><strong>Database:</strong> <?= defined('DB_NAME') ? '✅ ' . DB_NAME : '❌ Not configured' ?></li>
                <li><strong>Database Host:</strong> <?= defined('DB_HOST') ? '✅ ' . DB_HOST : '❌ Not configured' ?></li>
                <li><strong>Session Started:</strong> <?= session_status() === PHP_SESSION_ACTIVE ? '✅ Yes' : '❌ No' ?></li>
                <li><strong>PHP Version:</strong> <?= PHP_VERSION ?></li>
            </ul>
        </div>

        <p style="text-align: center; margin-top: 30px;">
            <a href="index.php" style="color: #6366f1;">← Back to Home</a> |
            <a href="dashboard.php" style="color: #6366f1;">Dashboard →</a>
        </p>
    </div>
</body>

</html>