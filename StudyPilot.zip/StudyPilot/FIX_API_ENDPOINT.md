# Quick Fix: Correct Gemini API Endpoint

## The Issue
The API version in the URL is wrong. The model `gemini-1.5-flash` requires **v1** not **v1beta**.

## The Fix

Open `includes/config.php` and update line 22:

**Change FROM:**
```php
define('GEMINI_API_ENDPOINT', 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent');
```

**Change TO:**
```php
define('GEMINI_API_ENDPOINT', 'https://generativelanguage.googleapis.com/v1/models/gemini-1.5-flash:generateContent');
```

**Notice:** Changed `v1beta` → `v1`

## After Update

1. Save `config.php`
2. Test: `http://localhost/StudyPilot/debug_api.php`
3. Should see: ✅ HTTP Status Code: 200
4. Then generate your study plan!

---

**Alternative models that work with v1:**
- `gemini-1.5-flash` (recommended - fast, high quota)
- `gemini-1.5-pro` (more capable, lower quota)
- `gemini-1.0-pro` (older, stable)
