<?php

/**
 * List Available Gemini Models
 * Shows which models your API key can access
 */

require_once __DIR__ . '/includes/config.php';

echo "<!DOCTYPE html><html><head><meta charset='UTF-8'><title>Available Models</title>";
echo "<style>body{font-family:monospace;padding:20px;background:#1f2937;color:#fff;}";
echo ".box{background:#374151;padding:15px;margin:10px 0;border-radius:8px;overflow-x:auto;}";
echo ".success{color:#10b981;} .error{color:#ef4444;} .model{background:#1f2937;padding:10px;margin:5px 0;border-left:3px solid #6366f1;}</style></head><body>";

echo "<h2>📋 Available Gemini Models</h2>";

// List models endpoint
$url = 'https://generativelanguage.googleapis.com/v1/models?key=' . GEMINI_API_KEY;

echo "<div class='box'>";
echo "<p><strong>Fetching available models...</strong></p>";

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 30);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode === 200) {
    $data = json_decode($response, true);

    if ($data && isset($data['models'])) {
        echo "<p class='success'>✅ Found " . count($data['models']) . " models</p>";

        echo "<h3>Models that support generateContent:</h3>";

        foreach ($data['models'] as $model) {
            $name = $model['name'] ?? 'Unknown';
            $displayName = $model['displayName'] ?? 'Unknown';
            $supportedMethods = $model['supportedGenerationMethods'] ?? [];

            if (in_array('generateContent', $supportedMethods)) {
                echo "<div class='model'>";
                echo "<strong>Name:</strong> " . htmlspecialchars($name) . "<br>";
                echo "<strong>Display Name:</strong> " . htmlspecialchars($displayName) . "<br>";
                echo "<strong>Methods:</strong> " . implode(', ', $supportedMethods) . "<br>";

                // Show how to use it
                $modelPath = str_replace('models/', '', $name);
                echo "<br><strong>Use this in config.php:</strong><br>";
                echo "<code style='background:#000;padding:5px;display:block;margin-top:5px;'>";
                echo "define('GEMINI_API_ENDPOINT', 'https://generativelanguage.googleapis.com/v1/models/" . htmlspecialchars($modelPath) . ":generateContent');";
                echo "</code>";
                echo "</div>";
            }
        }
    } else {
        echo "<p class='error'>❌ Unexpected response format</p>";
        echo "<pre>" . htmlspecialchars($response) . "</pre>";
    }
} else {
    echo "<p class='error'>❌ Failed to fetch models (HTTP $httpCode)</p>";
    echo "<pre>" . htmlspecialchars($response) . "</pre>";
}

echo "</div>";

echo "<div class='box'>";
echo "<h3>📝 Next Steps:</h3>";
echo "<ol>";
echo "<li>Copy one of the <code>define('GEMINI_API_ENDPOINT', ...)</code> lines above</li>";
echo "<li>Open <code>includes/config.php</code></li>";
echo "<li>Replace line 22 with the copied line</li>";
echo "<li>Save and test at: <a href='debug_api.php' style='color:#60a5fa;'>debug_api.php</a></li>";
echo "</ol>";
echo "</div>";

echo "</body></html>";
