<?php

/**
 * StudyPilot AI - Landing Page / Home
 */

require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/functions.php';

// Redirect to dashboard if logged in
if (isLoggedIn()) {
    redirect('dashboard.php');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>StudyPilot AI - AI-Powered Study Planner</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body class="landing-page">
    <header class="hero">
        <nav class="navbar">
            <div class="container">
                <div class="nav-brand">
                    <h2>📚 StudyPilot AI</h2>
                </div>
                <div class="nav-links">
                    <a href="login.php" class="btn btn-outline">Log In</a>
                    <a href="register.php" class="btn btn-primary">Get Started</a>
                </div>
            </div>
        </nav>

        <div class="hero-content">
            <div class="container">
                <h1 class="hero-title">Your AI-Powered Study Companion</h1>
                <p class="hero-subtitle">
                    Generate personalized, adaptive study plans tailored to your subjects,
                    schedule, and exam deadlines. Stay on track with intelligent rescheduling
                    and focus mode.
                </p>
                <div class="hero-cta">
                    <a href="register.php" class="btn btn-primary btn-large">
                        Start Planning Now →
                    </a>
                </div>
            </div>
        </div>
    </header>

    <section class="features">
        <div class="container">
            <h2 class="section-title">Why StudyPilot AI?</h2>

            <div class="features-grid">
                <div class="feature-card">
                    <div class="feature-icon">🤖</div>
                    <h3>AI-Generated Plans</h3>
                    <p>Get personalized study schedules based on your subjects, difficulty levels, and available time.</p>
                </div>

                <div class="feature-card">
                    <div class="feature-icon">🔄</div>
                    <h3>Adaptive Rescheduling</h3>
                    <p>Skipped a task? No problem. AI automatically rebalances your remaining schedule.</p>
                </div>

                <div class="feature-card">
                    <div class="feature-icon">🎯</div>
                    <h3>Focus Mode</h3>
                    <p>Eliminate distractions with one-task-at-a-time view and built-in countdown timer.</p>
                </div>

                <div class="feature-card">
                    <div class="feature-icon">📊</div>
                    <h3>Progress Tracking</h3>
                    <p>See your completion percentage and get insights on whether you're on track.</p>
                </div>

                <div class="feature-card">
                    <div class="feature-icon">📅</div>
                    <h3>Day-by-Day Schedule</h3>
                    <p>Clear, color-coded daily tasks organized by priority and difficulty.</p>
                </div>

                <div class="feature-card">
                    <div class="feature-icon">⚡</div>
                    <h3>Smart Prioritization</h3>
                    <p>AI prioritizes harder subjects and distributes study time realistically.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="how-it-works">
        <div class="container">
            <h2 class="section-title">How It Works</h2>

            <div class="steps">
                <div class="step">
                    <div class="step-number">1</div>
                    <h3>Enter Your Details</h3>
                    <p>Add your subjects, difficulty levels, available study hours, and exam date.</p>
                </div>

                <div class="step">
                    <div class="step-number">2</div>
                    <h3>AI Generates Your Plan</h3>
                    <p>Our AI creates a realistic, day-by-day study schedule optimized for success.</p>
                </div>

                <div class="step">
                    <div class="step-number">3</div>
                    <h3>Study & Track Progress</h3>
                    <p>Follow your plan, mark tasks complete, and watch your progress grow.</p>
                </div>

                <div class="step">
                    <div class="step-number">4</div>
                    <h3>Adapt as Needed</h3>
                    <p>Life happens. Skip tasks and let AI reschedule them automatically.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="cta-section">
        <div class="container">
            <h2>Ready to Ace Your Exams?</h2>
            <p>Join students who are studying smarter with AI-powered planning.</p>
            <a href="register.php" class="btn btn-primary btn-large">
                Create Free Account
            </a>
        </div>
    </section>

    <footer class="footer">
        <div class="container">
            <p>&copy; 2026 StudyPilot AI. Built for students, powered by AI.</p>
        </div>
    </footer>
</body>

</html>