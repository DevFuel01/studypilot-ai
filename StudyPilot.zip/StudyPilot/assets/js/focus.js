/**
 * StudyPilot AI - Focus Mode JavaScript
 * Countdown timer and task completion handling
 */

let timerInterval = null;
let remainingSeconds = 0;
let isPaused = false;

/**
 * Start the countdown timer
 */
function startTimer(durationMinutes) {
    remainingSeconds = durationMinutes * 60;
    isPaused = false;
    
    // Hide start button, show pause button
    document.getElementById('startBtn').style.display = 'none';
    document.getElementById('pauseBtn').style.display = 'inline-block';
    document.getElementById('resumeBtn').style.display = 'none';
    
    // Start countdown
    runTimer();
}

/**
 * Run the timer countdown
 */
function runTimer() {
    timerInterval = setInterval(() => {
        if (!isPaused && remainingSeconds > 0) {
            remainingSeconds--;
            updateTimerDisplay();
            
            // Timer finished
            if (remainingSeconds === 0) {
                clearInterval(timerInterval);
                playNotificationSound();
                showTimerComplete();
            }
        }
    }, 1000);
}

/**
 * Pause the timer
 */
function pauseTimer() {
    isPaused = true;
    document.getElementById('pauseBtn').style.display = 'none';
    document.getElementById('resumeBtn').style.display = 'inline-block';
}

/**
 * Resume the timer
 */
function resumeTimer() {
    isPaused = false;
    document.getElementById('pauseBtn').style.display = 'inline-block';
    document.getElementById('resumeBtn').style.display = 'none';
}

/**
 * Update timer display
 */
function updateTimerDisplay() {
    const minutes = Math.floor(remainingSeconds / 60);
    const seconds = remainingSeconds % 60;
    
    document.getElementById('minutes').textContent = String(minutes).padStart(2, '0');
    document.getElementById('seconds').textContent = String(seconds).padStart(2, '0');
}

/**
 * Show timer complete message
 */
function showTimerComplete() {
    const timerDisplay = document.getElementById('timerDisplay');
    timerDisplay.style.color = '#10b981';
    timerDisplay.innerHTML = '<span style="font-size: 3rem;">🎉 Time\'s Up!</span>';
    
    // Hide timer controls
    document.querySelector('.timer-controls').style.display = 'none';
}

/**
 * Play notification sound (simple beep using Web Audio API)
 */
function playNotificationSound() {
    try {
        const audioContext = new (window.AudioContext || window.webkitAudioContext)();
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        
        oscillator.frequency.value = 800;
        oscillator.type = 'sine';
        
        gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
        
        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + 0.5);
    } catch (error) {
        console.log('Audio notification not supported');
    }
}

/**
 * Complete current task
 */
async function completeTask(taskId) {
    if (confirm('Mark this task as completed?')) {
        await updateTask(taskId, 'completed');
    }
}

/**
 * Skip current task
 */
async function skipTask(taskId) {
    if (confirm('Skip this task? It will be automatically rescheduled.')) {
        await updateTask(taskId, 'skipped');
    }
}

/**
 * Update task status and load next task
 */
async function updateTask(taskId, status) {
    console.log(`Updating task ${taskId} to ${status}...`);
    
    // UI Feedback
    const btn = status === 'completed' ? 
        document.querySelector('.btn-success') : 
        document.querySelector('.btn-outline');
    
    if (btn) {
        const originalText = btn.innerHTML;
        btn.innerHTML = '⏳ Updating...';
        btn.disabled = true;
    }

    try {
        const response = await fetch('api/update_task.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                taskId: taskId,
                status: status
            })
        });
        
        // Read text first to debug non-JSON errors
        const text = await response.text();
        console.log('API Response:', text);

        let data;
        try {
            data = JSON.parse(text);
        } catch (e) {
            throw new Error('Invalid server response: ' + text.substring(0, 100));
        }
        
        if (data.success) {
            // Stop timer if running
            if (timerInterval) {
                clearInterval(timerInterval);
            }
            
            // Show success message and reload
            showSuccessMessage(status);
            setTimeout(() => {
                window.location.reload();
            }, 2000);
        } else {
            alert('Error: ' + data.message);
            if (btn) {
                btn.innerHTML = '❌ Failed';
                setTimeout(() => { btn.innerHTML = originalText; btn.disabled = false; }, 2000);
            }
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Failed: ' + error.message);
        if (btn) {
            btn.innerHTML = '❌ Error';
            btn.disabled = false;
        }
    }
}

/**
 * Show success message
 */
function showSuccessMessage(status) {
    const focusContent = document.querySelector('.focus-content');
    const message = status === 'completed' ? 'Great job! Task completed! 🎉' : 'Task skipped and rescheduled ⏭️';
    
    focusContent.innerHTML = `
        <div style="text-align: center; padding: 4rem 2rem;">
            <div style="font-size: 5rem; margin-bottom: 1.5rem;">
                ${status === 'completed' ? '✅' : '⏭️'}
            </div>
            <h2>${message}</h2>
            <p>Loading next task...</p>
        </div>
    `;
}

/**
 * Keyboard shortcuts
 */
document.addEventListener('keydown', function(e) {
    const focusContent = document.querySelector('.focus-content');
    if (!focusContent) return;
    
    const taskId = focusContent.dataset.taskId;
    if (!taskId) return;
    
    // Space = Start/Pause timer
    if (e.code === 'Space' && e.target.tagName !== 'BUTTON') {
        e.preventDefault();
        const startBtn = document.getElementById('startBtn');
        const pauseBtn = document.getElementById('pauseBtn');
        const resumeBtn = document.getElementById('resumeBtn');
        
        if (startBtn && startBtn.style.display !== 'none') {
            const duration = parseInt(startBtn.getAttribute('onclick').match(/\d+/)[0]);
            startTimer(duration);
        } else if (pauseBtn && pauseBtn.style.display !== 'none') {
            pauseTimer();
        } else if (resumeBtn && resumeBtn.style.display !== 'none') {
            resumeTimer();
        }
    }
    
    // Enter = Complete task
    if (e.code === 'Enter' && e.ctrlKey) {
        e.preventDefault();
        completeTask(parseInt(taskId));
    }
    
    // S = Skip task
    if (e.code === 'KeyS' && e.ctrlKey) {
        e.preventDefault();
        skipTask(parseInt(taskId));
    }
});

// Show keyboard shortcuts hint
document.addEventListener('DOMContentLoaded', function() {
    const focusContent = document.querySelector('.focus-content');
    if (focusContent) {
        const hint = document.createElement('div');
        hint.style.cssText = 'position: fixed; bottom: 20px; left: 50%; transform: translateX(-50%); background: rgba(0,0,0,0.8); color: white; padding: 1rem 2rem; border-radius: 8px; font-size: 0.875rem; text-align: center;';
        hint.innerHTML = 'Shortcuts: <strong>Space</strong> = Start/Pause | <strong>Ctrl+Enter</strong> = Complete | <strong>Ctrl+S</strong> = Skip';
        document.body.appendChild(hint);
        
        // Hide after 5 seconds
        setTimeout(() => {
            hint.style.opacity = '0';
            hint.style.transition = 'opacity 0.5s';
            setTimeout(() => hint.remove(), 500);
        }, 5000);
    }
});
