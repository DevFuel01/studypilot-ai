/**
 * StudyPilot AI - Dashboard JavaScript
 * Handles form submission, task updates, and dynamic UI
 */

// Set minimum exam date to tomorrow
document.addEventListener('DOMContentLoaded', function() {
    const examDateInput = document.getElementById('examDate');
    if (examDateInput) {
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        examDateInput.min = tomorrow.toISOString().split('T')[0];
    }
});

/**
 * Add a new subject row
 */
function addSubject() {
    const container = document.getElementById('subjectsContainer');
    const subjectRow = document.createElement('div');
    subjectRow.className = 'subject-row';
    subjectRow.innerHTML = `
        <input type="text" name="subject_name[]" placeholder="Subject name" required>
        <select name="subject_difficulty[]" required>
            <option value="easy">Easy</option>
            <option value="medium" selected>Medium</option>
            <option value="hard">Hard</option>
        </select>
        <button type="button" class="btn-remove" onclick="removeSubject(this)">✕</button>
    `;
    container.appendChild(subjectRow);
}

/**
 * Remove a subject row
 */
function removeSubject(button) {
    const container = document.getElementById('subjectsContainer');
    if (container.children.length > 1) {
        button.parentElement.remove();
    } else {
        alert('You must have at least one subject');
    }
}

/**
 * Handle study plan form submission
 */
const planForm = document.getElementById('planForm');
if (planForm) {
    planForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const generateBtn = document.getElementById('generateBtn');
        const loadingState = document.getElementById('loadingState');
        const formCard = document.querySelector('.plan-form-card');
        
        // Collect form data
        const subjectNames = document.querySelectorAll('input[name="subject_name[]"]');
        const subjectDifficulties = document.querySelectorAll('select[name="subject_difficulty[]"]');
        const hoursPerDay = document.getElementById('hoursPerDay').value;
        const examDate = document.getElementById('examDate').value;
        
        // Build subjects array
        const subjects = [];
        for (let i = 0; i < subjectNames.length; i++) {
            if (subjectNames[i].value.trim()) {
                subjects.push({
                    name: subjectNames[i].value.trim(),
                    difficulty: subjectDifficulties[i].value
                });
            }
        }
        
        if (subjects.length === 0) {
            alert('Please add at least one subject');
            return;
        }
        
        // Show loading state
        planForm.style.display = 'none';
        loadingState.style.display = 'block';
        
        try {
            const response = await fetch('api/generate_plan.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    subjects: subjects,
                    hoursPerDay: parseFloat(hoursPerDay),
                    examDate: examDate
                })
            });
            
            const data = await response.json();
            
            if (data.success) {
                // Reload page to show the new plan
                window.location.reload();
            } else {
                alert('Error: ' + data.message);
                planForm.style.display = 'block';
                loadingState.style.display = 'none';
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Failed to generate study plan. Please try again.');
            planForm.style.display = 'block';
            loadingState.style.display = 'none';
        }
    });
}

/**
 * Update task status (complete or skip)
 */
async function updateTaskStatus(taskId, status) {
    const taskCard = document.querySelector(`[data-task-id="${taskId}"]`);
    
    try {
        const response = await fetch('api/update_task.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                taskId: taskId,
                status: status
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            // Update task card appearance
            taskCard.classList.add('status-' + status);
            
            // Replace action buttons with status badge
            const actionsDiv = taskCard.querySelector('.task-actions');
            if (actionsDiv) {
                const badgeClass = status === 'completed' ? 'completed' : 'skipped';
                const badgeText = status === 'completed' ? '✓ Completed' : '⏭ Skipped';
                actionsDiv.outerHTML = `<div class="task-status-badge ${badgeClass}">${badgeText}</div>`;
            }
            
            // Update progress bar
            if (data.progress) {
                updateProgressDisplay(data.progress);
            }
            
            // Update insights
            if (data.insights) {
                updateInsightsDisplay(data.insights);
            }
            
            // Show success message
            showNotification(status === 'completed' ? 'Task completed!' : 'Task skipped and rescheduled', 'success');
        } else {
            alert('Error: ' + data.message);
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Failed to update task. Please try again.');
    }
}

/**
 * Update progress display
 */
function updateProgressDisplay(progress) {
    const progressBar = document.querySelector('.progress-bar');
    const progressText = document.querySelector('.progress-text');
    const progressStats = document.querySelector('.progress-stats');
    
    if (progressBar) {
        progressBar.style.width = progress.percentage + '%';
    }
    
    if (progressText) {
        progressText.textContent = progress.percentage + '% Complete';
    }
    
    if (progressStats) {
        progressStats.innerHTML = `
            <span>✅ ${progress.completed} Completed</span>
            <span>⏭️ ${progress.skipped} Skipped</span>
            <span>⏳ ${progress.pending} Pending</span>
        `;
    }
}

/**
 * Update insights display
 */
function updateInsightsDisplay(insights) {
    const insightsCard = document.querySelector('.insights-card');
    const insightsMessage = document.querySelector('.insights-message');
    const insightsDetail = document.querySelector('.insights-detail');
    
    if (insightsCard) {
        // Remove old status classes
        insightsCard.className = 'insights-card status-' + insights.status;
    }
    
    if (insightsMessage) {
        insightsMessage.textContent = insights.message;
    }
    
    if (insightsDetail) {
        insightsDetail.innerHTML = `
            ${insights.days_until_exam} days until exam<br>
            ${insights.actually_done} / ${insights.should_be_done} tasks completed so far
        `;
    }
}

/**
 * Show notification message
 */
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `alert alert-${type}`;
    notification.textContent = message;
    notification.style.position = 'fixed';
    notification.style.top = '20px';
    notification.style.right = '20px';
    notification.style.zIndex = '9999';
    notification.style.minWidth = '300px';
    notification.style.animation = 'slideIn 0.3s ease';
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

/**
 * Delete a task
 */
async function deleteTask(taskId) {
    if (!confirm('Are you sure you want to delete this task?')) {
        return;
    }
    
    // UI Feedback - find the task card
    const taskCard = document.querySelector(`[data-task-id="${taskId}"]`);
    if (taskCard) {
        taskCard.style.opacity = '0.5';
    }

    try {
        const response = await fetch('api/delete_task.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                taskId: taskId
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            // Remove task card
            if (taskCard) {
                // Check if this is the last task in the date group
                const dateGroup = taskCard.closest('.date-group');
                const taskCount = dateGroup.querySelectorAll('.task-card').length;
                
                taskCard.remove();
                
                if (taskCount <= 1) { // 1 because we haven't removed it from DOM yet? No, we just called remove(). Wait.
                   // Logic: taskCard.remove() happens first. So taskCount check should be on dateGroup query AFTER remove?
                   // Or before.
                }
                
                // Let's do it cleaner:
                if (dateGroup && dateGroup.querySelectorAll('.task-card').length === 0) {
                     dateGroup.remove();
                }
            }

            // Update progress
            if (data.progress) {
                updateProgressDisplay(data.progress);
            }
            
            // Update insights
            if (data.insights) {
                updateInsightsDisplay(data.insights);
            }
            
            showNotification('Task deleted', 'success');
        } else {
            alert('Error: ' + data.message);
            if (taskCard) taskCard.style.opacity = '1';
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Failed to delete task.');
        if (taskCard) taskCard.style.opacity = '1';
    }
}

// Add CSS animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(400px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(400px);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);
