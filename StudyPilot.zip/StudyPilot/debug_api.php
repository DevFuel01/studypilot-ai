<?php

/**
 * Detailed Gemini API Test
 * Shows exact API request and response for debugging
 */

require_once __DIR__ . '/includes/config.php';

echo "<!DOCTYPE html><html><head><meta charset='UTF-8'><title>API Debug</title>";
echo "<style>body{font-family:monospace;padding:20px;background:#1f2937;color:#fff;}";
echo ".box{background:#374151;padding:15px;margin:10px 0;border-radius:8px;overflow-x:auto;}";
echo ".success{color:#10b981;} .error{color:#ef4444;} .warning{color:#f59e0b;}</style></head><body>";

echo "<h2>🔍 Gemini API Debug Test</h2>";

// Test 1: Check API Key
echo "<div class='box'>";
echo "<h3>1. API Key Check</h3>";
if (GEMINI_API_KEY === 'YOUR_GEMINI_API_KEY_HERE') {
    echo "<p class='error'>❌ API key not configured</p>";
    exit;
} else {
    echo "<p class='success'>✅ API key configured (length: " . strlen(GEMINI_API_KEY) . ")</p>";
    echo "<p>First 10 chars: " . substr(GEMINI_API_KEY, 0, 10) . "...</p>";
}
echo "</div>";

// Test 2: Check Endpoint
echo "<div class='box'>";
echo "<h3>2. API Endpoint</h3>";
echo "<p>" . GEMINI_API_ENDPOINT . "</p>";
echo "</div>";

// Test 3: Make API Request
echo "<div class='box'>";
echo "<h3>3. API Request Test</h3>";

$testPrompt = "Say only the word 'HELLO' if you can read this.";
$requestData = [
    'contents' => [
        [
            'parts' => [
                ['text' => $testPrompt]
            ]
        ]
    ],
    'generationConfig' => [
        'temperature' => 0.7,
        'maxOutputTokens' => 100,
    ]
];

$url = GEMINI_API_ENDPOINT . '?key=' . GEMINI_API_KEY;

echo "<p><strong>Request URL:</strong></p>";
echo "<pre>" . htmlspecialchars(str_replace(GEMINI_API_KEY, 'API_KEY_HIDDEN', $url)) . "</pre>";

echo "<p><strong>Request Body:</strong></p>";
echo "<pre>" . htmlspecialchars(json_encode($requestData, JSON_PRETTY_PRINT)) . "</pre>";

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($requestData));
curl_setopt($ch, CURLOPT_TIMEOUT, 30);
curl_setopt($ch, CURLOPT_VERBOSE, true);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlError = curl_error($ch);
curl_close($ch);

echo "<p><strong>HTTP Status Code:</strong> ";
if ($httpCode === 200) {
    echo "<span class='success'>$httpCode ✅</span></p>";
} else {
    echo "<span class='error'>$httpCode ❌</span></p>";
}

if ($curlError) {
    echo "<p class='error'><strong>cURL Error:</strong> $curlError</p>";
}

echo "<p><strong>Response:</strong></p>";
echo "<pre>" . htmlspecialchars($response) . "</pre>";

// Try to parse response
if ($httpCode === 200) {
    $data = json_decode($response, true);
    if ($data && isset($data['candidates'][0]['content']['parts'][0]['text'])) {
        $aiResponse = $data['candidates'][0]['content']['parts'][0]['text'];
        echo "<p class='success'><strong>✅ AI Response:</strong> " . htmlspecialchars($aiResponse) . "</p>";
    } else {
        echo "<p class='warning'><strong>⚠️ Unexpected response structure</strong></p>";
    }
} else {
    // Parse error response
    $errorData = json_decode($response, true);
    if ($errorData && isset($errorData['error'])) {
        echo "<p class='error'><strong>API Error:</strong></p>";
        echo "<pre>" . htmlspecialchars(json_encode($errorData['error'], JSON_PRETTY_PRINT)) . "</pre>";
    }
}

echo "</div>";

// Test 4: Recommendations
echo "<div class='box'>";
echo "<h3>4. Recommendations</h3>";
if ($httpCode !== 200) {
    echo "<ul>";
    echo "<li>Check if your API key is valid at: <a href='https://aistudio.google.com/app/apikey' style='color:#60a5fa;'>Google AI Studio</a></li>";
    echo "<li>Verify the API key has Gemini API access enabled</li>";
    echo "<li>Try using gemini-1.5-flash instead of gemini-2.0-flash-exp</li>";
    echo "<li>Check if you have API quota remaining</li>";
    echo "</ul>";
} else {
    echo "<p class='success'>✅ API is working! You can now use StudyPilot AI.</p>";
    echo "<p><a href='dashboard.php' style='color:#60a5fa;'>Go to Dashboard →</a></p>";
}
echo "</div>";

echo "</body></html>";
