<?php

/**
 * StudyPilot AI - Helper Functions
 * Authentication, study plan management, and utility functions
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';

// ============================================
// AUTHENTICATION FUNCTIONS
// AUTHENTICATION FUNCTIONS
// ============================================

/**
 * Register a new user
 * 
 * @param string $email User email
 * @param string $password Plain text password
 * @param string $name User's full name
 * @return array Success status and message
 */
function registerUser($email, $password, $name)
{
    $db = getDB();

    // Validate email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return ['success' => false, 'message' => 'Invalid email format'];
    }

    // Validate password strength
    if (strlen($password) < 6) {
        return ['success' => false, 'message' => 'Password must be at least 6 characters'];
    }

    // Check if email already exists
    $stmt = $db->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->execute([$email]);
    if ($stmt->fetch()) {
        return ['success' => false, 'message' => 'Email already registered'];
    }

    // Hash password
    $passwordHash = password_hash($password, PASSWORD_BCRYPT, ['cost' => PASSWORD_COST]);

    // Insert user
    try {
        $stmt = $db->prepare("INSERT INTO users (email, password_hash, name) VALUES (?, ?, ?)");
        $stmt->execute([$email, $passwordHash, $name]);
        return ['success' => true, 'message' => 'Registration successful', 'user_id' => $db->lastInsertId()];
    } catch (PDOException $e) {
        error_log("Registration error: " . $e->getMessage());
        return ['success' => false, 'message' => 'Registration failed'];
    }
}

/**
 * Authenticate user login
 * 
 * @param string $email User email
 * @param string $password Plain text password
 * @return array Success status and user data
 */
function loginUser($email, $password)
{
    $db = getDB();

    // Get user by email
    $stmt = $db->prepare("SELECT id, email, password_hash, name FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if (!$user) {
        return ['success' => false, 'message' => 'Invalid email or password'];
    }

    // Verify password
    if (!password_verify($password, $user['password_hash'])) {
        return ['success' => false, 'message' => 'Invalid email or password'];
    }

    // Set session variables
    session_regenerate_id(true);
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_email'] = $user['email'];
    $_SESSION['user_name'] = $user['name'];
    $_SESSION['login_time'] = time();

    return [
        'success' => true,
        'message' => 'Login successful',
        'user' => [
            'id' => $user['id'],
            'email' => $user['email'],
            'name' => $user['name']
        ]
    ];
}

/**
 * Logout current user
 */
function logoutUser()
{
    $_SESSION = [];
    session_destroy();
    setcookie(session_name(), '', time() - 3600, '/');
}

/**
 * Check if user is logged in
 * 
 * @return bool True if logged in
 */
function isLoggedIn()
{
    if (!isset($_SESSION['user_id'])) {
        return false;
    }

    // Check session timeout
    if (isset($_SESSION['login_time']) && (time() - $_SESSION['login_time'] > SESSION_TIMEOUT)) {
        logoutUser();
        return false;
    }

    return true;
}

/**
 * Get current logged-in user data
 * 
 * @return array|null User data or null if not logged in
 */
function getCurrentUser()
{
    if (!isLoggedIn()) {
        return null;
    }

    return [
        'id' => $_SESSION['user_id'],
        'email' => $_SESSION['user_email'],
        'name' => $_SESSION['user_name']
    ];
}

/**
 * Require user to be logged in (redirect if not)
 * 
 * @param string $redirectUrl Where to redirect if not logged in
 */
function requireLogin($redirectUrl = 'login.php')
{
    if (!isLoggedIn()) {
        redirect($redirectUrl);
    }
}

// ============================================
// STUDY PLAN MANAGEMENT FUNCTIONS
// ============================================

/**
 * Save AI-generated study plan to database
 * 
 * @param array $planData Plan data from AI
 * @param int $userId User ID
 * @param float $hoursPerDay Study hours per day
 * @param string $examDate Exam date
 * @return int|false Plan ID or false on failure
 */
function savePlanToDatabase($planData, $userId, $hoursPerDay, $examDate)
{
    $db = getDB();

    try {
        $db->beginTransaction();

        // Insert study plan
        $stmt = $db->prepare("INSERT INTO study_plans (user_id, total_hours, exam_date, status) VALUES (?, ?, ?, 'active')");
        $stmt->execute([$userId, $hoursPerDay, $examDate]);
        $planId = $db->lastInsertId();

        // Group tasks by subject to insert subjects first
        $subjectMap = [];
        $subjectDifficulty = []; // Track difficulty per subject

        foreach ($planData['tasks'] as $task) {
            if (!isset($subjectMap[$task['subject']])) {
                // Determine difficulty from task or default to medium
                $difficulty = isset($task['difficulty']) ? $task['difficulty'] : 'medium';

                // Validate difficulty
                if (!in_array($difficulty, ['easy', 'medium', 'hard'])) {
                    $difficulty = 'medium';
                }

                $subjectDifficulty[$task['subject']] = $difficulty;

                // Insert subject
                $stmt = $db->prepare("INSERT INTO subjects (plan_id, name, difficulty, priority_score) VALUES (?, ?, ?, 0)");
                $stmt->execute([$planId, $task['subject'], $difficulty]);
                $subjectMap[$task['subject']] = $db->lastInsertId();

                error_log("Created subject: " . $task['subject'] . " with difficulty: " . $difficulty);
            }
        }

        // Insert tasks
        foreach ($planData['tasks'] as $task) {
            // Validate required fields
            if (!isset($task['subject'], $task['date'], $task['duration'], $task['description'])) {
                error_log("Skipping invalid task: " . json_encode($task));
                continue;
            }

            $subjectId = $subjectMap[$task['subject']];
            $stmt = $db->prepare("INSERT INTO tasks (plan_id, subject_id, study_date, duration, description, status) VALUES (?, ?, ?, ?, ?, 'pending')");
            $stmt->execute([
                $planId,
                $subjectId,
                $task['date'],
                (int)$task['duration'],
                $task['description']
            ]);

            error_log("Created task for " . $task['subject'] . " on " . $task['date']);
        }

        $db->commit();
        error_log("Successfully saved plan ID: " . $planId);
        return $planId;
    } catch (PDOException $e) {
        $db->rollBack();
        error_log("Save plan error: " . $e->getMessage());
        error_log("Plan data: " . json_encode($planData));
        return false;
    }
}

/**
 * Get active study plan for user
 * 
 * @param int $userId User ID
 * @return array|null Plan data or null if not found
 */
function getActivePlan($userId)
{
    $db = getDB();

    $stmt = $db->prepare("SELECT * FROM study_plans WHERE user_id = ? AND status = 'active' ORDER BY created_at DESC LIMIT 1");
    $stmt->execute([$userId]);
    $plan = $stmt->fetch();

    if (!$plan) {
        return null;
    }

    // Get subjects
    $stmt = $db->prepare("SELECT * FROM subjects WHERE plan_id = ?");
    $stmt->execute([$plan['id']]);
    $plan['subjects'] = $stmt->fetchAll();

    // Get tasks
    $stmt = $db->prepare("SELECT t.*, s.name as subject_name, s.difficulty FROM tasks t JOIN subjects s ON t.subject_id = s.id WHERE t.plan_id = ? ORDER BY t.study_date ASC, t.id ASC");
    $stmt->execute([$plan['id']]);
    $plan['tasks'] = $stmt->fetchAll();

    return $plan;
}

/**
 * Get all study plans for user
 * 
 * @param int $userId User ID
 * @return array Array of plans
 */
function getUserPlans($userId)
{
    $db = getDB();

    $stmt = $db->prepare("SELECT * FROM study_plans WHERE user_id = ? ORDER BY created_at DESC");
    $stmt->execute([$userId]);
    return $stmt->fetchAll();
}

/**
 * Update task status
 * 
 * @param int $taskId Task ID
 * @param string $status New status (completed, skipped, pending)
 * @return bool Success status
 */
function updateTaskStatus($taskId, $status)
{
    $db = getDB();

    $validStatuses = ['pending', 'completed', 'skipped'];
    if (!in_array($status, $validStatuses)) {
        return false;
    }

    try {
        $stmt = $db->prepare("UPDATE tasks SET status = ? WHERE id = ?");
        $stmt->execute([$status, $taskId]);
        return true;
    } catch (PDOException $e) {
        error_log("Update task status error: " . $e->getMessage());
        return false;
    }
}

/**
 * Reschedule skipped tasks adaptively
 * 
 * @param int $planId Plan ID
 * @return bool Success status
 */
function rescheduleSkippedTasks($planId)
{
    $db = getDB();

    try {
        // Get all skipped tasks
        $stmt = $db->prepare("SELECT * FROM tasks WHERE plan_id = ? AND status = 'skipped' ORDER BY study_date ASC");
        $stmt->execute([$planId]);
        $skippedTasks = $stmt->fetchAll();

        if (empty($skippedTasks)) {
            return true;
        }

        // Get plan details
        $stmt = $db->prepare("SELECT exam_date FROM study_plans WHERE id = ?");
        $stmt->execute([$planId]);
        $plan = $stmt->fetch();

        // Find available dates (dates with less total duration)
        $stmt = $db->prepare("
            SELECT study_date, SUM(duration) as total_duration 
            FROM tasks 
            WHERE plan_id = ? AND status = 'pending' AND study_date >= CURDATE()
            GROUP BY study_date 
            ORDER BY total_duration ASC, study_date ASC
        ");
        $stmt->execute([$planId]);
        $availableDates = $stmt->fetchAll();

        // Reschedule each skipped task
        $dateIndex = 0;
        foreach ($skippedTasks as $task) {
            if ($dateIndex >= count($availableDates)) {
                // Add new date if needed
                $lastDate = end($availableDates)['study_date'] ?? date('Y-m-d');
                $newDate = date('Y-m-d', strtotime($lastDate . ' +1 day'));

                // Don't schedule past exam date
                if ($newDate > $plan['exam_date']) {
                    break;
                }

                $availableDates[] = ['study_date' => $newDate, 'total_duration' => 0];
            }

            $newDate = $availableDates[$dateIndex]['study_date'];

            // Update task
            $stmt = $db->prepare("UPDATE tasks SET study_date = ?, status = 'pending', original_date = ? WHERE id = ?");
            $stmt->execute([$newDate, $task['study_date'], $task['id']]);

            $dateIndex++;
        }

        return true;
    } catch (PDOException $e) {
        error_log("Reschedule error: " . $e->getMessage());
        return false;
    }
}

/**
 * Calculate progress percentage for a plan
 * 
 * @param int $planId Plan ID
 * @return array Progress data
 */
function calculateProgress($planId)
{
    $db = getDB();

    $stmt = $db->prepare("
        SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
            SUM(CASE WHEN status = 'skipped' THEN 1 ELSE 0 END) as skipped,
            SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending
        FROM tasks 
        WHERE plan_id = ?
    ");
    $stmt->execute([$planId]);
    $stats = $stmt->fetch();

    $percentage = $stats['total'] > 0 ? round(($stats['completed'] / $stats['total']) * 100) : 0;

    return [
        'total' => (int)$stats['total'],
        'completed' => (int)$stats['completed'],
        'skipped' => (int)$stats['skipped'],
        'pending' => (int)$stats['pending'],
        'percentage' => $percentage
    ];
}

/**
 * Get insights about study plan progress
 * 
 * @param int $planId Plan ID
 * @return array Insights data
 */
function getInsights($planId)
{
    $db = getDB();

    // Get plan details
    $stmt = $db->prepare("SELECT exam_date, total_hours FROM study_plans WHERE id = ?");
    $stmt->execute([$planId]);
    $plan = $stmt->fetch();

    // Calculate days until exam
    $today = new DateTime();
    $examDate = new DateTime($plan['exam_date']);
    $daysUntil = $today->diff($examDate)->days;

    // Get tasks that should have been completed by now
    $stmt = $db->prepare("
        SELECT COUNT(*) as should_be_done 
        FROM tasks 
        WHERE plan_id = ? AND study_date < CURDATE()
    ");
    $stmt->execute([$planId]);
    $shouldBeDone = $stmt->fetch()['should_be_done'];

    // Get actually completed tasks up to today
    $stmt = $db->prepare("
        SELECT COUNT(*) as actually_done 
        FROM tasks 
        WHERE plan_id = ? AND study_date < CURDATE() AND status = 'completed'
    ");
    $stmt->execute([$planId]);
    $actuallyDone = $stmt->fetch()['actually_done'];

    // Determine status
    $status = 'on-track';
    $message = 'You are on track with your study plan!';

    if ($shouldBeDone > 0) {
        $completionRate = ($actuallyDone / $shouldBeDone) * 100;

        if ($completionRate < 50) {
            $status = 'behind';
            $message = 'You are falling behind. Try to catch up!';
        } elseif ($completionRate < 80) {
            $status = 'slightly-behind';
            $message = 'You are slightly behind schedule.';
        } elseif ($completionRate >= 100) {
            $status = 'ahead';
            $message = 'Great job! You are ahead of schedule!';
        }
    }

    return [
        'status' => $status,
        'message' => $message,
        'days_until_exam' => $daysUntil,
        'should_be_done' => $shouldBeDone,
        'actually_done' => $actuallyDone
    ];
}

/**
 * Get subject-wise performance stats
 * 
 * @param int $planId Plan ID
 * @return array Subject stats
 */
function getSubjectStats($planId)
{
    $db = getDB();

    // Get completion rates by subject
    $stmt = $db->prepare("
        SELECT 
            s.name,
            s.id,
            COUNT(t.id) as total_tasks,
            SUM(CASE WHEN t.status = 'completed' THEN 1 ELSE 0 END) as completed,
            SUM(CASE WHEN t.status = 'skipped' THEN 1 ELSE 0 END) as skipped,
            SUM(CASE WHEN t.status = 'completed' THEN t.duration ELSE 0 END) as total_minutes,
            SUM(CASE WHEN t.status = 'pending' THEN 1 ELSE 0 END) as pending
        FROM subjects s
        JOIN tasks t ON s.id = t.subject_id
        WHERE s.plan_id = ?
        GROUP BY s.id, s.name
        HAVING total_tasks > 0
    ");
    $stmt->execute([$planId]);
    $subjectStats = $stmt->fetchAll();

    $stats = [];
    $strongestSubject = null;
    $weakestSubject = null;
    $highestRate = -1;
    $highestSkipRate = -1;

    foreach ($subjectStats as $sub) {
        $completionRate = ($sub['completed'] / $sub['total_tasks']) * 100;
        $skipRate = ($sub['skipped'] / $sub['total_tasks']) * 100;

        // Format duration
        $hours = floor($sub['total_minutes'] / 60);
        $minutes = $sub['total_minutes'] % 60;
        $timeString = $hours > 0 ? "{$hours}h {$minutes}m" : "{$minutes}m";

        $stats[] = [
            'name' => $sub['name'],
            'total' => $sub['total_tasks'],
            'completed' => $sub['completed'],
            'skipped' => $sub['skipped'],
            'minutes' => $sub['total_minutes'],
            'time_string' => $timeString,
            'rate' => round($completionRate)
        ];

        // Determine strongest (best completion)
        if ($sub['completed'] > 0 && $completionRate > $highestRate) {
            $highestRate = $completionRate;
            $strongestSubject = $sub['name'] . " (" . round($completionRate) . "%)";
        }

        // Determine weakest (most skipped)
        if ($sub['skipped'] > 0 && $skipRate > $highestSkipRate) {
            $highestSkipRate = $skipRate;
            $weakestSubject = $sub['name'] . " (" . round($skipRate) . "% skipped)";
        }
    }

    return [
        'subjects' => $stats,
        'strongest' => $strongestSubject ?: 'None yet',
        'weakest' => $weakestSubject ?: 'None yet'
    ];
}

/**
 * Get next pending task for Focus Mode
 * 
 * @param int $planId Plan ID
 * @return array|null Next task or null
 */
function getNextTask($planId)
{
    $db = getDB();

    $stmt = $db->prepare("
        SELECT t.*, s.name as subject_name, s.difficulty 
        FROM tasks t 
        JOIN subjects s ON t.subject_id = s.id 
        WHERE t.plan_id = ? AND t.status = 'pending' 
        ORDER BY t.study_date ASC, t.id ASC 
        LIMIT 1
    ");
    $stmt->execute([$planId]);
    return $stmt->fetch();
}
