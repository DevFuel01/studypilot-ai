<?php

function strictCleanJSON($text)
{
    // 1. Extract JSON block
    $start = strpos($text, '{');
    $end = strrpos($text, '}');
    if ($start !== false && $end !== false) {
        $text = substr($text, $start, $end - $start + 1);
    }

    // 2. Brutal cleaning - regex replace all whitespace chars with space
    // This includes \n, \r, \t, \f, \v
    $text = preg_replace('/\s+/u', ' ', $text);

    return trim($text);
}

function parseGeminiWithFallback($response)
{
    // Basic JSON decode first
    $data = json_decode($response, true);
    if (!$data || !isset($data['candidates'][0]['content']['parts'][0]['text'])) {
        return ['error' => 'Invalid AI response structure'];
    }

    $rawText = $data['candidates'][0]['content']['parts'][0]['text'];
    error_log("Parser Raw Text: " . substr($rawText, 0, 100));

    // Try standard clean & decode
    $cleanText = strictCleanJSON($rawText);
    $studyPlan = json_decode($cleanText, true);

    if ($studyPlan && isset($studyPlan['tasks'])) {
        return validateTasks($studyPlan['tasks']);
    }

    error_log("Standard JSON decode failed. Trying Regex Fallback.");

    // Regex Fallback
    // Match task objects manually
    // {"subject": "Math", "date": "2025-01-01", "duration": 90, "description": "Desc"}
    $tasks = [];

    // Normalize text for regex
    $normText = str_replace(["\r\n", "\r", "\n"], " ", $rawText);

    // Pattern to match objects
    // We look for "subject" ... "date" ... "duration" ... "description"
    // This allows for loose JSON (e.g. missing commas or quotes)
    $pattern = '/"subject"\s*:\s*"(.*?)"\s*,\s*"date"\s*:\s*"(.*?)"\s*,\s*"duration"\s*:\s*(\d+)\s*,\s*"description"\s*:\s*"(.*?)"/s';

    if (preg_match_all($pattern, $normText, $matches, PREG_SET_ORDER)) {
        foreach ($matches as $match) {
            $tasks[] = [
                'subject' => $match[1],
                'date' => $match[2],
                'duration' => (int)$match[3],
                'description' => $match[4]
            ];
        }
    }

    if (!empty($tasks)) {
        error_log("Regex fallback found " . count($tasks) . " tasks.");
        return validateTasks($tasks);
    }

    return ['error' => 'Failed to parse tasks via JSON or Regex.'];
}

function validateTasks($tasks)
{
    $validTasks = [];
    foreach ($tasks as $task) {
        if (isset($task['subject'], $task['date'], $task['duration'], $task['description'])) {
            if (DateTime::createFromFormat('Y-m-d', $task['date']) !== false) {
                // Clean description of any escaped quotes
                $task['description'] = stripslashes($task['description']);
                $validTasks[] = $task;
            }
        }
    }

    if (empty($validTasks)) {
        return ['error' => 'No valid tasks found after parsing.'];
    }

    return ['tasks' => $validTasks];
}
