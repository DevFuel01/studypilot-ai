<?php

/**
 * StudyPilot AI - Configuration File
 * Contains database credentials, API keys, and application settings
 * 
 * SECURITY: Add this file to .gitignore to protect sensitive credentials
 */

// ============================================
// DATABASE CONFIGURATION
// ============================================
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');  // Update with your MySQL password
define('DB_NAME', 'studypilot');

// ============================================
// GOOGLE GEMINI API CONFIGURATION
// ============================================
define('GEMINI_API_KEY', 'your-actual-api-key-here');  // Replace with your actual API key

define('GEMINI_API_ENDPOINT', 'https://generativelanguage.googleapis.com/v1/models/gemini-2.5-flash:generateContent');

// ============================================
// SESSION CONFIGURATION
// ============================================
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_secure', 0);  // Set to 1 if using HTTPS
ini_set('session.cookie_samesite', 'Strict');
session_start();

// ============================================
// APPLICATION SETTINGS
// ============================================
date_default_timezone_set('UTC');

// Error reporting (disable in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Password hashing settings
define('PASSWORD_COST', 10);

// Session timeout (in seconds) - 24 hours
define('SESSION_TIMEOUT', 86400);

// ============================================
// APPLICATION PATHS
// ============================================
define('BASE_PATH', dirname(__DIR__));
define('INCLUDES_PATH', BASE_PATH . '/includes');
define('API_PATH', BASE_PATH . '/api');

// ============================================
// HELPER FUNCTION: Redirect
// ============================================
function redirect($url)
{
    header("Location: $url");
    exit();
}

// ============================================
// HELPER FUNCTION: JSON Response
// ============================================
function jsonResponse($data, $statusCode = 200)
{
    http_response_code($statusCode);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit();
}

// ============================================
// HELPER FUNCTION: Sanitize Input
// ============================================
function sanitizeInput($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $data;
}
