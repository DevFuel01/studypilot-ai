<?php

/**
 * StudyPilot AI - Google Gemini API Handler
 * Handles AI integration for study plan generation
 */

require_once __DIR__ . '/config.php';

/**
 * Generate study plan using Google Gemini API
 * 
 * @param array $subjects Array of subjects with difficulty levels
 * @param float $hoursPerDay Available study hours per day
 * @param string $examDate Exam deadline (Y-m-d format)
 * @return array|false Parsed AI response or false on failure
 */
function generateStudyPlan($subjects, $hoursPerDay, $examDate)
{
    // Calculate days until exam
    $today = new DateTime();
    $exam = new DateTime($examDate);
    $daysUntil = $today->diff($exam)->days;

    if ($daysUntil <= 0) {
        return ['error' => 'Exam date must be in the future'];
    }

    // Build subject list for prompt
    $subjectList = [];
    foreach ($subjects as $subject) {
        $subjectList[] = "- {$subject['name']} (Difficulty: {$subject['difficulty']})";
    }
    $subjectText = implode("\n", $subjectList);

    // Construct AI prompt
    $prompt = <<<PROMPT
You are an expert study planning assistant. Create a realistic, day-by-day study schedule based on the following information:

**Student Information:**
- Available study hours per day: {$hoursPerDay} hours
- Exam date: {$examDate} ({$daysUntil} days from now)

**Subjects to study:**
{$subjectText}

**Instructions:**
1. Prioritize harder subjects (allocate more time)
2. Distribute study time realistically across all days
3. Include variety - don't schedule the same subject for too long
4. Each task should be 30-120 minutes
5. Leave some buffer time for breaks
6. Create specific, actionable task descriptions

**CRITICAL: Return ONLY valid JSON in this exact format (no markdown, no explanation):**
**IMPORTANT: Do NOT include newlines or line breaks inside values (like descriptions). Keep everything on one line.**
{
  "tasks": [
    {
      "subject": "Subject Name",
      "date": "YYYY-MM-DD",
      "duration": 90,
      "description": "Specific task description (must be a single line string)"
    }
  ]
}

Generate the study plan now:
PROMPT;

    // Prepare API request
    $requestData = [
        'contents' => [
            [
                'parts' => [
                    ['text' => $prompt]
                ]
            ]
        ],
        'generationConfig' => [
            'temperature' => 0.7,
            'topK' => 40,
            'topP' => 0.95,
            'maxOutputTokens' => 4096,
        ]
    ];

    // Make API call
    $ch = curl_init(GEMINI_API_ENDPOINT . '?key=' . GEMINI_API_KEY);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json'
    ]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($requestData));
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);

    // Handle cURL errors
    if ($curlError) {
        error_log("Gemini API cURL Error: " . $curlError);
        return ['error' => 'Network error: ' . $curlError];
    }

    // Handle HTTP errors
    if ($httpCode !== 200) {
        error_log("Gemini API HTTP Error: " . $httpCode . " - " . substr($response, 0, 500));

        // Try to parse error response
        $errorData = json_decode($response, true);
        if ($errorData && isset($errorData['error']['message'])) {
            return ['error' => 'AI API Error: ' . $errorData['error']['message']];
        }

        return ['error' => 'AI API returned HTTP ' . $httpCode];
    }

    // Parse response
    require_once __DIR__ . '/ai_parser.php';
    return parseGeminiWithFallback($response);
}

/**
 * Parse Gemini API response and extract study plan
 * 
 * @param string $response Raw API response
 * @return array|false Parsed study plan or false on failure
 */
function parseGeminiResponse($response)
{
    $data = json_decode($response, true);

    if (!$data || !isset($data['candidates'][0]['content']['parts'][0]['text'])) {
        error_log("Invalid Gemini response structure: " . substr($response, 0, 500));
        return ['error' => 'Invalid AI response structure'];
    }

    $aiText = $data['candidates'][0]['content']['parts'][0]['text'];

    // Log start of text for debugging
    error_log("Raw AI Text (Start): " . substr($aiText, 0, 100));

    // 1. Extract JSON block (between first { and last })
    $start = strpos($aiText, '{');
    $end = strrpos($aiText, '}');

    if ($start !== false && $end !== false) {
        $aiText = substr($aiText, $start, $end - $start + 1);
    } else {
        return ['error' => 'AI did not return a JSON object'];
    }

    // 2. Simple cleaning: Replace all newline variations and tabs with spaces
    // This removes actual control characters
    $aiText = str_replace(["\r\n", "\r", "\n", "\t"], " ", $aiText);

    // 3. Decode
    $studyPlan = json_decode($aiText, true);

    if (!$studyPlan) {
        $jsonError = json_last_error_msg();
        error_log("JSON decode error: " . $jsonError);
        error_log("Cleaned JSON (first 500): " . substr($aiText, 0, 500));
        return ['error' => 'Failed to parse AI response. JSON Error: ' . $jsonError];
    }

    if (!isset($studyPlan['tasks']) || !is_array($studyPlan['tasks'])) {
        error_log("Invalid study plan structure: " . json_encode($studyPlan));
        return ['error' => 'AI response missing tasks array'];
    }

    // Validate tasks
    $validTasks = [];
    $invalidCount = 0;

    foreach ($studyPlan['tasks'] as $task) {
        if (isset($task['subject'], $task['date'], $task['duration'], $task['description'])) {
            // Validate date format
            if (DateTime::createFromFormat('Y-m-d', $task['date']) !== false) {
                $validTasks[] = $task;
            } else {
                $invalidCount++;
                error_log("Invalid date format in task: " . $task['date']);
            }
        } else {
            $invalidCount++;
            error_log("Task missing required fields: " . json_encode($task));
        }
    }

    if (empty($validTasks)) {
        error_log("No valid tasks found. Invalid count: " . $invalidCount);
        return ['error' => 'No valid tasks in AI response. Check that dates are in YYYY-MM-DD format.'];
    }

    error_log("Successfully parsed " . count($validTasks) . " valid tasks (skipped " . $invalidCount . " invalid)");
    return ['tasks' => $validTasks];
}

/**
 * Test Gemini API connection
 * 
 * @return bool True if API is working
 */
function testGeminiAPI()
{
    $testPrompt = "Respond with only the word 'SUCCESS' if you can read this.";

    $requestData = [
        'contents' => [
            ['parts' => [['text' => $testPrompt]]]
        ]
    ];

    $ch = curl_init(GEMINI_API_ENDPOINT . '?key=' . GEMINI_API_KEY);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($requestData));
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    return $httpCode === 200;
}
