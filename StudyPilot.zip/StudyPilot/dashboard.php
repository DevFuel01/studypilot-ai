<?php

/**
 * StudyPilot AI - Main Dashboard
 * Study plan creation and management
 */

require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';

// Require authentication
requireLogin();

$user = getCurrentUser();
$activePlan = getActivePlan($user['id']);
$progress = null;
$insights = null;

if ($activePlan) {
    $progress = calculateProgress($activePlan['id']);
    $insights = getInsights($activePlan['id']);
    $subjectStats = getSubjectStats($activePlan['id']);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - StudyPilot AI</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body class="dashboard-page">
    <nav class="dashboard-nav">
        <div class="container">
            <div class="nav-brand">
                <h2>📚 StudyPilot AI</h2>
            </div>
            <div class="nav-user">
                <span>Welcome, <?= htmlspecialchars($user['name']) ?>!</span>
                <a href="logout.php" class="btn btn-outline btn-sm">Logout</a>
            </div>
        </div>
    </nav>

    <main class="dashboard-main">
        <div class="container">
            <?php if (!$activePlan): ?>
                <!-- No active plan - show creation form -->
                <div class="welcome-section">
                    <h1>Create Your Study Plan</h1>
                    <p>Let AI generate a personalized study schedule based on your needs.</p>
                </div>

                <div class="plan-form-card">
                    <form id="planForm" class="plan-form">
                        <div class="form-section">
                            <h3>Your Subjects</h3>
                            <div id="subjectsContainer">
                                <div class="subject-row">
                                    <input type="text" name="subject_name[]" placeholder="Subject name (e.g., Mathematics)" required>
                                    <select name="subject_difficulty[]" required>
                                        <option value="easy">Easy</option>
                                        <option value="medium" selected>Medium</option>
                                        <option value="hard">Hard</option>
                                    </select>
                                    <button type="button" class="btn-remove" onclick="removeSubject(this)" style="display:none;">✕</button>
                                </div>
                            </div>
                            <button type="button" class="btn btn-secondary" onclick="addSubject()">+ Add Subject</button>
                        </div>

                        <div class="form-section">
                            <h3>Study Schedule</h3>
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="hoursPerDay">Hours per day</label>
                                    <input type="number" id="hoursPerDay" name="hoursPerDay" min="0.5" max="12" step="0.5" value="4" required>
                                    <small>How many hours can you study each day?</small>
                                </div>

                                <div class="form-group">
                                    <label for="examDate">Exam Date</label>
                                    <input type="date" id="examDate" name="examDate" required>
                                    <small>When is your exam or deadline?</small>
                                </div>
                            </div>
                        </div>

                        <div class="form-actions">
                            <button type="submit" class="btn btn-primary btn-large" id="generateBtn">
                                Generate Study Plan with AI 🤖
                            </button>
                        </div>
                    </form>

                    <div id="loadingState" class="loading-state" style="display:none;">
                        <div class="spinner"></div>
                        <p>AI is generating your personalized study plan...</p>
                    </div>
                </div>

            <?php else: ?>
                <!-- Active plan exists - show dashboard -->
                <div class="dashboard-header">
                    <div>
                        <h1>Your Study Plan</h1>
                        <p>Exam Date: <?= date('F j, Y', strtotime($activePlan['exam_date'])) ?></p>
                    </div>
                    <div class="dashboard-actions">
                        <a href="focus.php" class="btn btn-primary">🎯 Focus Mode</a>
                    </div>
                </div>

                <!-- Progress Section -->
                <div class="progress-section">
                    <div class="progress-card">
                        <h3>Overall Progress</h3>
                        <div class="progress-bar-container">
                            <div class="progress-bar" style="width: <?= $progress['percentage'] ?>%"></div>
                        </div>
                        <p class="progress-text"><?= $progress['percentage'] ?>% Complete</p>
                        <div class="progress-stats">
                            <span>✅ <?= $progress['completed'] ?> Completed</span>
                            <span>⏭️ <?= $progress['skipped'] ?> Skipped</span>
                            <span>⏳ <?= $progress['pending'] ?> Pending</span>
                        </div>
                    </div>

                    <div class="insights-card status-<?= $insights['status'] ?>">
                        <h3>Status</h3>
                        <p class="insights-message"><?= htmlspecialchars($insights['message']) ?></p>
                        <p class="insights-detail">
                            <?= $insights['days_until_exam'] ?> days until exam<br>
                            <?= $insights['actually_done'] ?> / <?= $insights['should_be_done'] ?> tasks completed so far
                        </p>
                    </div>

                    <div class="subject-card">
                        <h3>Subject Insights</h3>
                        <div class="stat-row">
                            <div class="stat-icon">💪</div>
                            <div class="stat-content">
                                <strong>Strongest Subject</strong>
                                <span><?= $subjectStats['strongest'] ?></span>
                            </div>
                        </div>
                        <div class="stat-row">
                            <div class="stat-icon">⚠️</div>
                            <div class="stat-content">
                                <strong>Needs Focus</strong>
                                <span><?= $subjectStats['weakest'] ?></span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="time-card">
                    <h3>Time Studied</h3>
                    <?php
                    // Find max minutes for relative bar scaling
                    $maxMinutes = 1;
                    foreach ($subjectStats['subjects'] as $sub) {
                        if ($sub['minutes'] > $maxMinutes) $maxMinutes = $sub['minutes'];
                    }

                    foreach ($subjectStats['subjects'] as $sub): ?>
                        <div class="time-row">
                            <div class="time-info">
                                <span class="subject-name"><?= htmlspecialchars($sub['name']) ?></span>
                                <span class="time-val"><?= $sub['time_string'] ?></span>
                            </div>
                            <div class="time-bar-bg">
                                <div class="time-bar-fill" style="width: <?= ($sub['minutes'] / $maxMinutes) * 100 ?>%"></div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
        </div>

        <!-- Tasks by Date -->
        <div class="tasks-section">
            <h2>Study Schedule</h2>
            <?php
                $tasksByDate = [];
                foreach ($activePlan['tasks'] as $task) {
                    $tasksByDate[$task['study_date']][] = $task;
                }

                foreach ($tasksByDate as $date => $tasks):
                    $dateObj = new DateTime($date);
                    $isToday = $dateObj->format('Y-m-d') === date('Y-m-d');
                    $isPast = $dateObj < new DateTime('today');
            ?>
                <div class="date-group <?= $isToday ? 'today' : '' ?> <?= $isPast ? 'past' : '' ?>">
                    <h3 class="date-header">
                        📅 <?= $dateObj->format('l, F j, Y') ?>
                        <?php if ($isToday): ?>
                            <span class="badge badge-today">Today</span>
                        <?php endif; ?>
                    </h3>

                    <div class="tasks-grid">
                        <?php foreach ($tasks as $task):
                            $difficultyIcon = $task['difficulty'] === 'hard' ? '🔥' : ($task['difficulty'] === 'medium' ? '⚡' : '🌱');
                        ?>
                            <div class="task-card difficulty-<?= $task['difficulty'] ?> status-<?= $task['status'] ?>" data-task-id="<?= $task['id'] ?>">
                                <div class="task-header">
                                    <h4><?= htmlspecialchars($task['subject_name']) ?></h4>
                                    <div class="task-meta">
                                        <span class="difficulty-icon" title="<?= ucfirst($task['difficulty']) ?> Priority"><?= $difficultyIcon ?></span>
                                        <span class="task-duration">⏱️ <?= $task['duration'] ?>m</span>
                                    </div>
                                </div>
                                <p class="task-description"><?= htmlspecialchars($task['description']) ?></p>

                                <?php if ($task['status'] === 'pending'): ?>
                                    <div class="task-actions">
                                        <button class="btn btn-success btn-sm" onclick="updateTaskStatus(<?= $task['id'] ?>, 'completed')">
                                            ✓ Complete
                                        </button>
                                        <button class="btn btn-secondary btn-sm" onclick="updateTaskStatus(<?= $task['id'] ?>, 'skipped')">
                                            ⏭ Skip
                                        </button>
                                        <button class="btn btn-danger btn-sm" onclick="deleteTask(<?= $task['id'] ?>)" title="Delete Task">
                                            ✕
                                        </button>
                                    </div>
                                <?php elseif ($task['status'] === 'completed'): ?>
                                    <div class="task-status-badge completed">✓ Completed</div>
                                <?php else: ?>
                                    <div class="task-status-badge skipped">⏭ Skipped</div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    </div>
    </main>

    <script src="assets/js/dashboard.js"></script>
</body>

</html>