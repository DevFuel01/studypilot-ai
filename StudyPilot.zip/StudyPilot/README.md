# StudyPilot AI 📚

An AI-powered study planner that helps students generate personalized, adaptive study plans based on their subjects, difficulty levels, available study hours, and exam deadlines.

## 🎯 Features

- **AI-Generated Study Plans**: Personalized schedules using Google Gemini API
- **Adaptive Rescheduling**: Automatically rebalances tasks when you skip
- **Focus Mode**: Distraction-free single-task view with countdown timer
- **Progress Tracking**: Real-time completion percentage and insights
- **User Authentication**: Secure registration and login system
- **Responsive Design**: Works seamlessly on desktop, tablet, and mobile

## 🛠️ Tech Stack

- **Frontend**: HTML5, CSS3, JavaScript (Vanilla)
- **Backend**: PHP 7.4+
- **Database**: MySQL 5.7+
- **AI Integration**: Google Gemini API
- **Architecture**: MVC-style with clean separation of concerns

## 📋 Prerequisites

- **XAMPP** (or similar LAMP/WAMP stack)
  - Apache 2.4+
  - PHP 7.4+
  - MySQL 5.7+
- **Google Gemini API Key** ([Get one here](https://makersuite.google.com/app/apikey))

## 🚀 Installation & Setup

### Step 1: Clone/Download Project

Place the `StudyPilot` folder in your XAMPP `htdocs` directory:
```
C:\xampp\htdocs\StudyPilot\
```

### Step 2: Create Database

1. Start XAMPP and ensure Apache and MySQL are running
2. Open phpMyAdmin: `http://localhost/phpmyadmin`
3. Import the database schema:
   - Click "Import" tab
   - Choose file: `StudyPilot/database/schema.sql`
   - Click "Go"

This will create the `studypilot` database with all necessary tables and sample data.

### Step 3: Configure API Key

1. Open `includes/config.php`
2. Replace `YOUR_GEMINI_API_KEY_HERE` with your actual Gemini API key:

```php
define('GEMINI_API_KEY', 'your-actual-api-key-here');
```

### Step 4: Configure Database (if needed)

If your MySQL credentials differ from defaults, update these lines in `includes/config.php`:

```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');  // Your MySQL password
define('DB_NAME', 'studypilot');
```

### Step 5: Access the Application

Open your browser and navigate to:
```
http://localhost/StudyPilot
```

## 👤 Test Account

A test account is automatically created with the database:

- **Email**: `test@studypilot.com`
- **Password**: `password123`

Or create your own account using the registration page.

## 📖 How to Use

### 1. Create Account / Login
- Register with your email and password
- Or use the test account credentials

### 2. Generate Study Plan
- Add your subjects with difficulty levels (easy, medium, hard)
- Set your available study hours per day
- Choose your exam date
- Click "Generate Study Plan with AI"

### 3. Manage Your Tasks
- View your day-by-day schedule
- Mark tasks as "Complete" or "Skip"
- Skipped tasks are automatically rescheduled
- Track your progress percentage

### 4. Use Focus Mode
- Click "🎯 Focus Mode" from dashboard
- See one task at a time
- Use the countdown timer
- Complete or skip tasks
- Keyboard shortcuts:
  - `Space` = Start/Pause timer
  - `Ctrl+Enter` = Complete task
  - `Ctrl+S` = Skip task

## 📁 Project Structure

```
StudyPilot/
├── index.php                 # Landing page
├── login.php                 # User login
├── register.php              # User registration
├── logout.php                # Logout handler
├── dashboard.php             # Main dashboard
├── focus.php                 # Focus Mode
├── api/
│   ├── generate_plan.php     # AI plan generation
│   ├── update_task.php       # Task status updates
│   └── reschedule.php        # Manual rescheduling
├── includes/
│   ├── config.php            # Configuration
│   ├── db.php                # Database connection
│   ├── ai_handler.php        # Gemini API integration
│   └── functions.php         # Helper functions
├── assets/
│   ├── css/
│   │   └── style.css         # Main stylesheet
│   └── js/
│       ├── dashboard.js      # Dashboard interactions
│       └── focus.js          # Focus Mode timer
├── database/
│   └── schema.sql            # Database schema
└── README.md                 # This file
```

## 🔒 Security Features

- **Password Hashing**: Using `password_hash()` with bcrypt
- **Prepared Statements**: All database queries use PDO prepared statements
- **Input Validation**: Server-side validation and sanitization
- **Session Security**: Secure session configuration with httponly cookies
- **API Key Protection**: Stored in config file (add to .gitignore)

## 🤖 AI Integration Details

### Google Gemini API

The system uses **Gemini 2.5 Flash** model to generate study plans:

**Input to AI:**
- List of subjects with difficulty levels
- Available study hours per day
- Days until exam

**AI Output:**
- Day-by-day task schedule
- Specific task descriptions
- Duration for each task (30-120 minutes)
- Smart prioritization based on difficulty

**Prompt Engineering:**
- Structured prompt for consistent JSON output
- Realistic time allocation
- Variety in subject distribution
- Buffer time for breaks

## 🎨 Design Highlights

- **Modern UI**: Vibrant gradient backgrounds, smooth animations
- **Color-Coded Tasks**: Easy (green), Medium (yellow), Hard (red)
- **Responsive**: Mobile-first design with breakpoints
- **Accessibility**: Semantic HTML, proper contrast ratios
- **User Feedback**: Loading states, notifications, progress bars

## 🐛 Troubleshooting

### Database Connection Failed
- Ensure MySQL is running in XAMPP
- Check database credentials in `config.php`
- Verify database `studypilot` exists

### AI Generation Failed
- Check your Gemini API key is valid
- Ensure you have internet connection
- Check PHP error logs in `xampp/apache/logs/error.log`

### Tasks Not Updating
- Check browser console for JavaScript errors
- Ensure you're logged in
- Verify API endpoints are accessible

## 📝 Future Enhancements

- Email notifications for upcoming tasks
- Study streak tracking
- Pomodoro technique integration
- Export study plan to calendar (iCal)
- Study group collaboration features
- Mobile app version

## 👨‍💻 Development

Built for hackathon submission demonstrating:
- Clean, readable code with comments
- Proper file organization
- Security best practices
- Real-world AI integration
- Responsive UX/UI design

## 📄 License

This project is created for educational and hackathon purposes.

## 🙏 Acknowledgments

- Google Gemini API for AI capabilities
- XAMPP for local development environment
- Modern web design inspiration from leading study apps

---

**Happy Studying! 🎓**

For questions or issues, please check the troubleshooting section or review the code comments.
