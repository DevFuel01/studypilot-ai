<?php

/**
 * StudyPilot AI - Focus Mode
 * Distraction-free single-task view with timer
 */

require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';

// Require authentication
requireLogin();

$user = getCurrentUser();
$activePlan = getActivePlan($user['id']);

if (!$activePlan) {
    redirect('dashboard.php');
}

$nextTask = getNextTask($activePlan['id']);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Focus Mode - StudyPilot AI</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body class="focus-page">
    <div class="focus-container">
        <div class="focus-header">
            <a href="dashboard.php" class="btn btn-outline btn-sm">← Back to Dashboard</a>
            <h2>🎯 Focus Mode</h2>
        </div>

        <?php if ($nextTask): ?>
            <div class="focus-content" data-task-id="<?= $nextTask['id'] ?>">
                <div class="focus-subject">
                    <span class="difficulty-badge difficulty-<?= $nextTask['difficulty'] ?>">
                        <?= ucfirst($nextTask['difficulty']) ?>
                    </span>
                    <h1><?= htmlspecialchars($nextTask['subject_name']) ?></h1>
                </div>

                <div class="focus-task">
                    <p><?= htmlspecialchars($nextTask['description']) ?></p>
                </div>

                <div class="focus-timer">
                    <div class="timer-display" id="timerDisplay">
                        <span id="minutes">00</span>:<span id="seconds">00</span>
                    </div>
                    <div class="timer-controls">
                        <button class="btn btn-primary" id="startBtn" onclick="startTimer(<?= $nextTask['duration'] ?>)">
                            Start Timer
                        </button>
                        <button class="btn btn-secondary" id="pauseBtn" onclick="pauseTimer()" style="display:none;">
                            Pause
                        </button>
                        <button class="btn btn-secondary" id="resumeBtn" onclick="resumeTimer()" style="display:none;">
                            Resume
                        </button>
                    </div>
                </div>

                <div class="focus-actions">
                    <button class="btn btn-success btn-large" onclick="completeTask(<?= $nextTask['id'] ?>)">
                        ✓ Done
                    </button>
                    <button class="btn btn-outline btn-large" onclick="skipTask(<?= $nextTask['id'] ?>)">
                        ⏭ Skip
                    </button>
                </div>
            </div>
        <?php else: ?>
            <div class="focus-empty">
                <div class="empty-icon">🎉</div>
                <h2>All Tasks Complete!</h2>
                <p>You've finished all pending tasks. Great work!</p>
                <a href="dashboard.php" class="btn btn-primary">Back to Dashboard</a>
            </div>
        <?php endif; ?>
    </div>

    <script src="assets/js/focus.js"></script>
</body>

</html>