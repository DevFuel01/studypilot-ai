-- StudyPilot AI Database Schema
-- MySQL Database for AI-Powered Study Planner
-- Created: 2026-01-02

-- Create database
CREATE DATABASE IF NOT EXISTS studypilot CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE studypilot;

-- ============================================
-- 1. USERS TABLE
-- ============================================
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    name VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 2. STUDY PLANS TABLE
-- ============================================
CREATE TABLE study_plans (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    total_hours DECIMAL(4,2) NOT NULL,
    exam_date DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('active', 'completed', 'archived') DEFAULT 'active',
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_status (user_id, status),
    INDEX idx_exam_date (exam_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 3. SUBJECTS TABLE
-- ============================================
CREATE TABLE subjects (
    id INT AUTO_INCREMENT PRIMARY KEY,
    plan_id INT NOT NULL,
    name VARCHAR(100) NOT NULL,
    difficulty ENUM('easy', 'medium', 'hard') NOT NULL,
    priority_score INT DEFAULT 0,
    FOREIGN KEY (plan_id) REFERENCES study_plans(id) ON DELETE CASCADE,
    INDEX idx_plan_id (plan_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 4. TASKS TABLE
-- ============================================
CREATE TABLE tasks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    plan_id INT NOT NULL,
    subject_id INT NOT NULL,
    study_date DATE NOT NULL,
    duration INT NOT NULL COMMENT 'Duration in minutes',
    description TEXT NOT NULL,
    status ENUM('pending', 'completed', 'skipped') DEFAULT 'pending',
    original_date DATE NULL COMMENT 'Original scheduled date before rescheduling',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (plan_id) REFERENCES study_plans(id) ON DELETE CASCADE,
    FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE,
    INDEX idx_plan_date (plan_id, study_date),
    INDEX idx_status (status),
    INDEX idx_subject (subject_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 5. USER SESSIONS TABLE
-- ============================================
CREATE TABLE user_sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    session_token VARCHAR(64) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP NULL DEFAULT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_token (session_token),
    INDEX idx_user_id (user_id),
    INDEX idx_expires (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- SAMPLE DATA FOR TESTING
-- ============================================

-- Insert test user (password: "password123")
INSERT INTO users (email, password_hash, name) VALUES 
('test@studypilot.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Test User');

-- Insert sample study plan
INSERT INTO study_plans (user_id, total_hours, exam_date, status) VALUES 
(1, 4.5, DATE_ADD(CURRENT_DATE, INTERVAL 14 DAY), 'active');

-- Insert sample subjects
INSERT INTO subjects (plan_id, name, difficulty, priority_score) VALUES 
(1, 'Mathematics', 'hard', 10),
(1, 'Physics', 'medium', 7),
(1, 'Chemistry', 'easy', 5);

-- Insert sample tasks
INSERT INTO tasks (plan_id, subject_id, study_date, duration, description, status) VALUES 
(1, 1, CURRENT_DATE, 90, 'Review calculus fundamentals - derivatives and integrals', 'pending'),
(1, 2, CURRENT_DATE, 60, 'Study Newton\'s laws of motion with practice problems', 'pending'),
(1, 3, DATE_ADD(CURRENT_DATE, INTERVAL 1 DAY), 45, 'Learn periodic table groups and properties', 'pending'),
(1, 1, DATE_ADD(CURRENT_DATE, INTERVAL 1 DAY), 90, 'Practice integration techniques', 'pending');
