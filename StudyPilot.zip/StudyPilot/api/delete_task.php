<?php

/**
 * StudyPilot AI - Delete Task API
 * Handles removal of tasks from the database
 */

header('Content-Type: application/json');

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';

// Check authentication
if (!isLoggedIn()) {
    jsonResponse(['success' => false, 'message' => 'Not authenticated'], 401);
}

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Invalid request method'], 405);
}

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

// Validate input
if (!isset($input['taskId'])) {
    jsonResponse(['success' => false, 'message' => 'Missing task ID'], 400);
}

$taskId = intval($input['taskId']);

// Verify task belongs to current user
$db = getDB();
$user = getCurrentUser();

// Join with study_plans to verify user ownership
$stmt = $db->prepare("
    SELECT t.id 
    FROM tasks t
    JOIN study_plans p ON t.plan_id = p.id
    WHERE t.id = ? AND p.user_id = ?
");
$stmt->execute([$taskId, $user['id']]);

$taskCheck = $stmt->fetch();

if (!$taskCheck) {
    error_log("Delete Access Denied: Task ID $taskId, User ID {$user['id']}");
    // Check if task exists at all to differentiate error
    $checkTask = $db->prepare("SELECT plan_id FROM tasks WHERE id = ?");
    $checkTask->execute([$taskId]);
    $existingTask = $checkTask->fetch();
    if ($existingTask) {
        error_log("Task $taskId exists but belongs to Plan " . $existingTask['plan_id']);
        // Verify plan owner
        $checkPlan = $db->prepare("SELECT user_id FROM study_plans WHERE id = ?");
        $checkPlan->execute([$existingTask['plan_id']]);
        $planOwner = $checkPlan->fetch();
        error_log("Plan " . $existingTask['plan_id'] . " belongs to User " . ($planOwner['user_id'] ?? 'N/A'));
    } else {
        error_log("Task $taskId does not exist in DB");
    }

    jsonResponse(['success' => false, 'message' => 'Task not found or access denied'], 403);
}

// Delete task
try {
    $stmt = $db->prepare("DELETE FROM tasks WHERE id = ?");
    $stmt->execute([$taskId]);

    // Potentially trigger manual rescheduling? 
    // For now, simpler is better. Deleting a task just frees up time.

    // Calculate new progress to return
    $stmt = $db->prepare("SELECT plan_id FROM study_plans WHERE user_id = ? AND status = 'active' LIMIT 1");
    $stmt->execute([$user['id']]);
    $plan = $stmt->fetch();

    $progress = [];
    $insights = [];

    if ($plan) {
        $progress = calculateProgress($plan['plan_id'] ?? 0); // Need Plan ID, not row ID if join... wait.
        // Actually, let's get plan_id from the task we just checked? Too late, deleted.
        // Re-fetch active plan ID.
        $activePlan = getActivePlan($user['id']);
        if ($activePlan) {
            $progress = calculateProgress($activePlan['id']);
            $insights = getInsights($activePlan['id']);
        }
    }

    jsonResponse([
        'success' => true,
        'message' => 'Task deleted',
        'progress' => $progress,
        'insights' => $insights
    ]);
} catch (PDOException $e) {
    error_log("Delete task error: " . $e->getMessage());
    jsonResponse(['success' => false, 'message' => 'Failed to delete task'], 500);
}
