<?php

/**
 * StudyPilot AI - Generate Study Plan API
 * Receives form data, calls AI, and saves plan to database
 */

header('Content-Type: application/json');

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/ai_handler.php';

// Check authentication
if (!isLoggedIn()) {
    jsonResponse(['success' => false, 'message' => 'Not authenticated'], 401);
}

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Invalid request method'], 405);
}

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

// Validate input
if (!isset($input['subjects']) || !isset($input['hoursPerDay']) || !isset($input['examDate'])) {
    jsonResponse(['success' => false, 'message' => 'Missing required fields'], 400);
}

$subjects = $input['subjects'];
$hoursPerDay = floatval($input['hoursPerDay']);
$examDate = $input['examDate'];

// Validate subjects array
if (!is_array($subjects) || empty($subjects)) {
    jsonResponse(['success' => false, 'message' => 'At least one subject is required'], 400);
}

// Validate hours
if ($hoursPerDay <= 0 || $hoursPerDay > 24) {
    jsonResponse(['success' => false, 'message' => 'Invalid study hours'], 400);
}

// Validate exam date
$examDateTime = DateTime::createFromFormat('Y-m-d', $examDate);
if (!$examDateTime || $examDateTime <= new DateTime()) {
    jsonResponse(['success' => false, 'message' => 'Exam date must be in the future'], 400);
}

// Prepare subjects for AI
$aiSubjects = [];
foreach ($subjects as $subject) {
    if (!isset($subject['name']) || !isset($subject['difficulty'])) {
        jsonResponse(['success' => false, 'message' => 'Invalid subject format'], 400);
    }

    $aiSubjects[] = [
        'name' => sanitizeInput($subject['name']),
        'difficulty' => in_array($subject['difficulty'], ['easy', 'medium', 'hard']) ? $subject['difficulty'] : 'medium'
    ];
}

// Generate study plan using AI
$studyPlan = generateStudyPlan($aiSubjects, $hoursPerDay, $examDate);

if (!$studyPlan || isset($studyPlan['error'])) {
    $errorMsg = $studyPlan['error'] ?? 'Failed to generate study plan';

    // Log detailed error for debugging
    error_log("StudyPilot AI Generation Error: " . $errorMsg);
    error_log("Subjects: " . json_encode($aiSubjects));
    error_log("Hours: " . $hoursPerDay . ", Exam Date: " . $examDate);

    jsonResponse(['success' => false, 'message' => $errorMsg, 'debug' => 'Check server error logs for details'], 500);
}

// Add difficulty mapping to tasks (AI might not include it)
$difficultyMap = [];
foreach ($aiSubjects as $subject) {
    $difficultyMap[$subject['name']] = $subject['difficulty'];
}

// Enrich tasks with difficulty from original subject data
foreach ($studyPlan['tasks'] as &$task) {
    if (!isset($task['difficulty']) && isset($difficultyMap[$task['subject']])) {
        $task['difficulty'] = $difficultyMap[$task['subject']];
    }
}
unset($task); // Break reference

error_log("Enriched study plan: " . json_encode($studyPlan));

// Save plan to database
$user = getCurrentUser();
$planId = savePlanToDatabase($studyPlan, $user['id'], $hoursPerDay, $examDate);

if (!$planId) {
    jsonResponse(['success' => false, 'message' => 'Failed to save study plan'], 500);
}

// Get the saved plan with all details
$savedPlan = getActivePlan($user['id']);

jsonResponse([
    'success' => true,
    'message' => 'Study plan generated successfully',
    'plan' => $savedPlan
], 200);
