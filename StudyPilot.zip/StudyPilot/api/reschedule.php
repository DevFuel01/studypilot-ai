<?php

/**
 * StudyPilot AI - Reschedule Tasks API
 * Manually trigger adaptive rescheduling for skipped tasks
 */

header('Content-Type: application/json');

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';

// Check authentication
if (!isLoggedIn()) {
    jsonResponse(['success' => false, 'message' => 'Not authenticated'], 401);
}

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Invalid request method'], 405);
}

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

// Validate input
if (!isset($input['planId'])) {
    jsonResponse(['success' => false, 'message' => 'Missing plan ID'], 400);
}

$planId = intval($input['planId']);

// Verify plan belongs to current user
$db = getDB();
$user = getCurrentUser();

$stmt = $db->prepare("SELECT id FROM study_plans WHERE id = ? AND user_id = ?");
$stmt->execute([$planId, $user['id']]);
$plan = $stmt->fetch();

if (!$plan) {
    jsonResponse(['success' => false, 'message' => 'Plan not found'], 404);
}

// Trigger rescheduling
$success = rescheduleSkippedTasks($planId);

if (!$success) {
    jsonResponse(['success' => false, 'message' => 'Failed to reschedule tasks'], 500);
}

// Get updated plan
$updatedPlan = getActivePlan($user['id']);

jsonResponse([
    'success' => true,
    'message' => 'Tasks rescheduled successfully',
    'plan' => $updatedPlan
], 200);
