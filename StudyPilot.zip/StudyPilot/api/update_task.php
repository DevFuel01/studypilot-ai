<?php

/**
 * StudyPilot AI - Update Task Status API
 * Updates task status (completed/skipped) and triggers rescheduling if needed
 */

header('Content-Type: application/json');

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';

// Check authentication
if (!isLoggedIn()) {
    jsonResponse(['success' => false, 'message' => 'Not authenticated'], 401);
}

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Invalid request method'], 405);
}

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

// Validate input
if (!isset($input['taskId']) || !isset($input['status'])) {
    jsonResponse(['success' => false, 'message' => 'Missing required fields'], 400);
}

$taskId = intval($input['taskId']);
$status = $input['status'];

// Validate status
if (!in_array($status, ['pending', 'completed', 'skipped'])) {
    jsonResponse(['success' => false, 'message' => 'Invalid status'], 400);
}

// Verify task belongs to current user
$db = getDB();
$user = getCurrentUser();

$stmt = $db->prepare("
    SELECT t.plan_id 
    FROM tasks t 
    JOIN study_plans sp ON t.plan_id = sp.id 
    WHERE t.id = ? AND sp.user_id = ?
");
$stmt->execute([$taskId, $user['id']]);
$task = $stmt->fetch();

if (!$task) {
    jsonResponse(['success' => false, 'message' => 'Task not found'], 404);
}

// Update task status
$success = updateTaskStatus($taskId, $status);

if (!$success) {
    jsonResponse(['success' => false, 'message' => 'Failed to update task'], 500);
}

// If task was skipped, trigger rescheduling
if ($status === 'skipped') {
    rescheduleSkippedTasks($task['plan_id']);
}

// Get updated progress
$progress = calculateProgress($task['plan_id']);
$insights = getInsights($task['plan_id']);

jsonResponse([
    'success' => true,
    'message' => 'Task updated successfully',
    'progress' => $progress,
    'insights' => $insights
], 200);
