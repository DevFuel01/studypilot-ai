<?php

/**
 * Direct API Test - Simulates dashboard form submission
 */

require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/ai_handler.php';

// Simulate being logged in
$_SESSION['user_id'] = 1;
$_SESSION['user_email'] = 'test@studypilot.com';
$_SESSION['user_name'] = 'Test User';
$_SESSION['login_time'] = time();

echo "<!DOCTYPE html><html><head><meta charset='UTF-8'><title>Direct API Test</title>";
echo "<style>body{font-family:monospace;padding:20px;background:#1f2937;color:#fff;}";
echo ".box{background:#374151;padding:15px;margin:10px 0;border-radius:8px;white-space:pre-wrap;}";
echo ".success{color:#10b981;} .error{color:#ef4444;} h3{color:#60a5fa;}</style></head><body>";

echo "<h2>🧪 Direct API Test</h2>";

// Test data
$subjects = [
    ['name' => 'Mathematics', 'difficulty' => 'hard'],
    ['name' => 'Physics', 'difficulty' => 'medium']
];
$hoursPerDay = 4;
$examDate = '2026-12-31';

echo "<div class='box'>";
echo "<h3>1. Input Data</h3>";
echo "Subjects: " . json_encode($subjects, JSON_PRETTY_PRINT) . "\n";
echo "Hours per day: $hoursPerDay\n";
echo "Exam date: $examDate\n";
echo "</div>";

// Step 1: Test AI Generation
echo "<div class='box'>";
echo "<h3>2. Testing AI Generation...</h3>";
$studyPlan = generateStudyPlan($subjects, $hoursPerDay, $examDate);

if (!$studyPlan || isset($studyPlan['error'])) {
    echo "<span class='error'>❌ AI Generation Failed</span>\n";
    echo "Error: " . ($studyPlan['error'] ?? 'Unknown error') . "\n";
    echo "</div></body></html>";
    exit;
}

echo "<span class='success'>✅ AI Generation Successful</span>\n";
echo "Tasks generated: " . count($studyPlan['tasks']) . "\n";
echo "\nRaw AI Response:\n" . json_encode($studyPlan, JSON_PRETTY_PRINT) . "\n";
echo "</div>";

// Step 2: Add difficulty mapping
echo "<div class='box'>";
echo "<h3>3. Adding Difficulty Mapping...</h3>";

$difficultyMap = [];
foreach ($subjects as $subject) {
    $difficultyMap[$subject['name']] = $subject['difficulty'];
}

foreach ($studyPlan['tasks'] as &$task) {
    if (!isset($task['difficulty']) && isset($difficultyMap[$task['subject']])) {
        $task['difficulty'] = $difficultyMap[$task['subject']];
    }
}
unset($task);

echo "<span class='success'>✅ Difficulty mapping added</span>\n";
echo "\nEnriched tasks:\n" . json_encode($studyPlan, JSON_PRETTY_PRINT) . "\n";
echo "</div>";

// Step 3: Test Database Save
echo "<div class='box'>";
echo "<h3>4. Testing Database Save...</h3>";

$user = getCurrentUser();
echo "Current user: " . json_encode($user) . "\n\n";

$planId = savePlanToDatabase($studyPlan, $user['id'], $hoursPerDay, $examDate);

if (!$planId) {
    echo "<span class='error'>❌ Database Save Failed</span>\n";
    echo "Check error logs for details\n";
} else {
    echo "<span class='success'>✅ Database Save Successful</span>\n";
    echo "Plan ID: $planId\n";
}
echo "</div>";

// Step 4: Retrieve saved plan
if ($planId) {
    echo "<div class='box'>";
    echo "<h3>5. Retrieving Saved Plan...</h3>";

    $savedPlan = getActivePlan($user['id']);

    if ($savedPlan) {
        echo "<span class='success'>✅ Plan Retrieved Successfully</span>\n";
        echo "Plan ID: " . $savedPlan['id'] . "\n";
        echo "Subjects: " . count($savedPlan['subjects']) . "\n";
        echo "Tasks: " . count($savedPlan['tasks']) . "\n";
        echo "\nFirst few tasks:\n";
        foreach (array_slice($savedPlan['tasks'], 0, 3) as $task) {
            echo "- " . $task['subject_name'] . " on " . $task['study_date'] . " (" . $task['duration'] . " min)\n";
        }
    } else {
        echo "<span class='error'>❌ Failed to retrieve plan</span>\n";
    }
    echo "</div>";
}

echo "<div class='box'>";
echo "<h3>✅ Test Complete!</h3>";
echo "If all steps passed, the issue is in the dashboard JavaScript or API endpoint.\n";
echo "If any step failed, check the error logs at: C:\\xampp\\apache\\logs\\error.log\n";
echo "</div>";

echo "<p><a href='dashboard.php' style='color:#60a5fa;'>Go to Dashboard →</a></p>";
echo "</body></html>";
