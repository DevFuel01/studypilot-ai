<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';

// Login as test user
loginUser('test@studypilot.com', 'password123'); // Assuming test user exists and password is 'password123'
// If not, we might need to create one or use existing session if run from browser
// But this is CLI/direct test.

// Get a pending task
$db = getDB();
$stmt = $db->query("SELECT id FROM tasks WHERE status = 'pending' LIMIT 1");
$task = $stmt->fetch();

if (!$task) {
    die("No pending tasks found to test.");
}

$taskId = $task['id'];
echo "Testing update for Task ID: $taskId\n";

// Prepare JSON payload
$data = json_encode(['taskId' => $taskId, 'status' => 'completed']);

// We can't easily cURL localhost from within the script unless we know the URL.
// Instead, let's include the API file, mocking the input!
// This is a hacky but effective way to test the logic without network networking.

// Mock $_SERVER and Input
$_SERVER['REQUEST_METHOD'] = 'POST';
// We need to override file_get_contents('php://input')... difficult.

// Alternative: Use cURL to localhost
$url = "http://localhost/StudyPilot/api/update_task.php";
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_COOKIE, "PHPSESSID=" . session_id()); // Pass session
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: $httpCode\n";
echo "Response: $response\n";

if ($httpCode == 200) {
    $json = json_decode($response, true);
    if ($json && $json['success']) {
        echo "✅ API Test PASSED\n";
    } else {
        echo "❌ API Test FAILED (Logic)\n";
    }
} else {
    echo "❌ API Test FAILED (HTTP Error)\n";
}
