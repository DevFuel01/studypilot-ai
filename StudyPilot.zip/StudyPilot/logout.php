<?php

/**
 * StudyPilot AI - Logout Handler
 */

require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/functions.php';

logoutUser();
redirect('index.php');
